<?php
//Ej1
function arraymax($numeros){
    if (empty($numeros)){
        return null;
    }

    $max = $numeros[0];
    foreach ($numeros as $numero){
        if ($numero > $max){
            $max = $numero;
        }
    }
    return $max;
}
$numeros = [1,2,3,4,5,6,7,23,9];
echo "Numeros max: ".arraymax($numeros) ."\n";

//EJ2
function sumArray($nums){
    if (empty($nums)){
        return null;
    }
    $suma = 0;
    foreach ($nums as $num) {
        $suma += $num;
    }
    return $suma;
}
$arrayNums = [1,2,3,4,5];
echo "Numeros suma: ".sumArray($arrayNums) ."\n";

//EJ3
function millas($distancia){
    $milla = 2;
    $distancia = 1.60934;
    $kilometroscount = $milla * $distancia;

    return $kilometroscount;
}
$kilometros = $kilometroscount = 0;
echo "Resultado: ".millas($kilometros) ."\n";

//EJ4
function palindromo($texto) {
    $texto = strtolower(str_replace(' ', '', $texto));
    return $texto == strrev($texto);
}
$consolatext = readline("Introduce la palabra: \n");

if (palindromo($consolatext)) {
    echo "Palindromo \n";
} else {
    echo "No palindromo \n";
}

//EJ5
function apletra($texto, $letra){
    $texto = strtolower($texto);
    $letra = strtolower($letra);

    $conteo = substr_count($texto, $letra);

    return $conteo;
}
    $texto = "Tengo un sueño que flipas";
    $letra = "e";


echo "La letra insertada se repite ". apletra($texto, $letra). " veces \n";

//EJ6
function subcadena($texto, $subcadena){
    $texto = strtolower($texto);
    $letra = strtolower($subcadena);

    $conteo = substr_count($texto, $subcadena);

    return $conteo;
}
$texto = "Tengo un sueño que flipas, un dia de estos me quedo dormio y to \n";
$subcadena = "un \n";

echo "La subcadena se repite ". subcadena($texto, $subcadena). " veces \n";

//EJ7
function mayusculas($texto){
    return ucwords($texto);
}
$texto = "hola mundo";
echo mayusculas($texto) ."\n";

//EJ8
function sumadigitos($numero){
    return array_sum(str_split($numero));
}
echo sumadigitos(456) "\n";

//EJ9
function mcd($numero1, $numero2){
    while ($numero2 != 0){
        $temp = $numero2;
        $numero2 = $numero1 % $numero2;
        $numero1 = $temp;
    }
    return $numero1;
}

echo mcd(20, 33) ."\n";

//EJ10
function fibonacci($numero) {
    if ($numero == 0) return 0;
    if ($numero == 1) return 1;
    return fibonacci($numero - 1) + fibonacci($numero - 2);
}
echo fibonacci(8) ."\n";

//EJ11
function primosRelativos($a, $b){
    while ($b != 0){
        $temp = $b;
        $b = $a % $b;
        $a = $temp;
    }
    return $a == 1;
}
$num1 = 22;
$num2 = 33;

if (primosRelativos($num1, $num2)) {
    echo "$num1 y $num2 3 si son primos \n";
} else {
    echo "$num1 y $num2 no son primos \n";
}

//EJ12
function capicua($numero){
    $texto = strval($numero);
    $revertir = strrev($texto);
    return $texto === $revertir;
}
$num = 1221;
if (capicua($num)) {
    echo "$num si es capicua, epico";
} else {
    echo "$num no es capicua \n";
}

//EJ13
function emmetFunc($emmet) {
    list($tag, $class) = explode('.', $emmet);
    return "<$tag class=\"$class\"></$tag>";
}

echo emmetFunc("div.oferta")."\n";

//EJ14
function mosaicoNumerico($num) {
    for ($i = 1; $i <= $num; $i++) {
        echo str_repeat($i, $i) . "\n";
    }
}
mosaicoNumerico(6) ."\n";
//EJ15
function compararArray($a, $b) {
   $resultados = [];
   for ($i = 0; $i < count($a); $i++) {
       $resultados[] = $a[$i] === $b[$i];
   }
   return $resultados;
}
print_r(compararArray([1, 2, 3], [1, 2, 4]));


//EJ16
function productoArray($numeros) {
   $resultados = 1;


   foreach ($numeros as $num) {
       $resultados *= $num;
   }
   return $resultados;
}
echo "producto: " .productoArray([2, 3, 4]) . "\n";


//EJ17
function arrayPares($numeros) {
   $pares = [];
   foreach ($numeros as $num) {
       if ($num % 2 == 0) {
           $pares[] = $num;
       }
   }
   return $pares;
}
print_r(arrayPares([1, 2, 3, 4, 5, 6]));


//EJ18
function esPrimo($numeros) {
   if ($numeros <= 1) return false;


   for ($i = 2; $i < $numeros; $i++) {
       if ($numeros % $i == 0) return false;
   }


   return true;
}
$num = 7;
if (esPrimo($num)) {
   echo "$num es primo\n";
} else {
   echo "$num no es primo \n";
}


//EJ19
function eliminarVocales($texto) {
   return str_replace(['a','e','i','o','u','A','E','I','O','U'], '', $texto);
}
echo eliminarVocales("Estoy de los juegos gachas hasta aquí, fucking ludopatía \n");


//EJ20
function factorial($num) {
   $resultados = 1;


   for ($i = 1; $i <= $num; $i++) {
       $resultados *= $i;
   }


   return $resultados;
}
echo "El factorial es: ".factorial(5). "\n";

//EJ21
function invertirCadena($texto) {
   return strrev($texto);
}
echo invertirCadena("webos con aceite");

//EJ22
function numPerfecto($numeros) {
   if ($numeros <= 1) return false;
   $suma = 0;
   for ($i = 1; $i <= $numeros / 2; $i++) {
       if ($numeros % $i == 0) {
           $suma += $i;
       }
   }
   return $suma == $numeros;
}
$num = 6;
if (numPerfecto($num)) {
   echo "$num es un número perfecto \n";
} else {
   echo "$num no es un número perfecto \n";
}
//EJ23
function numArmstrong($numeros) {
   $digitos = str_split($numeros);
   $numDigitos = count($digitos);
   $suma = 0;
   foreach ($digitos as $d) {
       $suma += pow($d, $numDigitos);
   }
   return $suma == $numeros;
}
$num = 153;
if (numArmstrong($num)) {
   echo "$num es un número Armstrong \n";
} else {
   echo "$num no es un número Armstrong \n";
}
//EJ24
define("descuento_estudiante", 0.15);
define("descuento_jubilado", 0.20);
define("descuento_vip", 0.25);


function descuentosCalcu($precio, $tipoDeCliente) {
   $descuentos = 0;


   if ($tipoDeCliente == "estudiante") {
       $descuentos = descuento_estudiante;
   } elseif ($tipoDeCliente == "jubilado") {
       $descuentos = descuento_jubilado;
   } elseif ($tipoDeCliente == "vip") {
       $descuentos = descuento_vip;
   }
   $precioFinal = $precio - ($precio * $descuentos);
   return $precioFinal;
}
echo "Precio : " . descuentosCalcu(100, " estudiante \n");
//EJ25
function notasMatch($nota) {
   return match (true) {
       $nota >= 9 && $nota <= 10 => "sobresaliente",
       $nota >= 7 && $nota <= 8  => "notable",
       $nota >= 5 && $nota <= 6  => "aprobado",
       $nota >= 0 && $nota <= 4  => "suspenso",
       default => "Nota no válida"
   };
}


echo "\n El alumno tiene como calificacion un: ".notasMatch(8)."\n";
//EJ26
function validarDatosNull($usuario) {
   return [
       'nombre' => $usuario['nombre'] ?? 'Anónimo',
       'email'  => $usuario['email']  ?? 'sin-email@example.com',
       'edad'   => $usuario['edad']   ?? 18,
       'ciudad' => $usuario['ciudad'] ?? 'Desconocida'
   ];
}
print_r(validarDatosNull(['nombre' => 'Juan', 'edad' => 25]));


//EJ27
function codigoPostal($usuario) {
   return $usuario?->direccion?->codigoPostal ?? "Código postal no disponible";
}


$usuario = (object)[
   'nombre' => 'Manu',
   'direccion' => (object)[
       'calle' => 'Diagonal',
       'ciudad' => 'Barcelona',
       'codigoPostal' => '17273'
   ]
];
echo codigoPostal($usuario)."\n";


//EJ28
$num1 = readline("Primer número: ");
$num2 = readline("Segundo número: ");
$operacion = readline("Operación (+, -, *, /): ");


if ($operacion == '+') {
   $res = $num1 + $num2;
} else if ($operacion == '-') {
   $res = $num1 - $num2;
} else if ($operacion == '*') {
   $res = $num1 * $num2;
} else if ($operacion == '/') {
   if ($num2 == 0) {
       echo "Error \n";
       exit;
   }
   $res = $num1 / $num2;
} else {
   echo "Error \n";
   exit;
}


echo "Resultado: $num1 $operacion $num2 = $res \n";


//EJ29
define("KELVIN", 273.15);
function convertirTemp($valor, $desde, $hasta) {
   echo "Función: " . __FUNCTION__ . " (línea " . __LINE__ . ")\n";


   if ($desde == "celsius" && $hasta == "fahrenheit") {
       return ($valor * 9/5) + 32;
   } elseif ($desde == "celsius" && $hasta == "kelvin") {
       return $valor + KELVIN;
   } elseif ($desde == "fahrenheit" && $hasta == "celsius") {
       return ($valor - 32) * 5/9;
   } elseif ($desde == "kelvin" && $hasta == "celsius") {
       return $valor - KELVIN;
   } else {
       return "Conversión no válida";
   }
}


echo convertirTemp(40, "celsius", "kelvin");

?>

